/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [" ./src//*.html"],
  darkMode: 'class', //Menambahkan opsi dark mode
  theme: {
    extend: {
      colors: {
        primary: '#FFB6C1', // Warna biru khusus
        secondary: '#FFC0CB', // Warna kuning khusus
      },
      fontFamily: {
        sans: ['Poppins', 'sans-serif'],
      },
    },
  },
  plugins: [],
}